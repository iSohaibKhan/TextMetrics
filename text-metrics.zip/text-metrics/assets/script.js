jQuery(document).ready(function($) {
    $('#text-metrics-form').submit(function(e) {
        e.preventDefault();

        // Disable the button
        $('#text-metrics-submit').addClass('disabled').attr('disabled', 'disabled');

        $.ajax({
            type: 'POST',
            url: textMetricsAjax.ajax_url,
            data: {
                action: 'text_metrics_action',
                text: $('#text-metrics-text').val()
            },
            success: function(response) {
                const data = JSON.parse(response);
                $('#word-count').text('Word Count: ' + data.word_count).removeClass('hidden');
                $('#char-count').text('Character Count: ' + data.char_count).removeClass('hidden');
                $('#sentence-count').text('Sentence Count: ' + data.sentence_count).removeClass('hidden');

                // Re-enable the button
                $('#text-metrics-submit').removeClass('disabled').removeAttr('disabled');
            }
        });
    });
});
