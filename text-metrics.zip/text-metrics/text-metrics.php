<?php
/**
 * Plugin Name: Text Metrics
 * Description: A simple WordPress plugin/tool for counting words, characters and sentences of a given text (To display it on the front-end use the shortcode [text_metrics]).
 * Version: 1.1.0
 * Author: Sohaib S. Khan
 * Author URI: https://isohaibkhan.github.io
 */
 
 // Register the shortcode
 add_shortcode('text_metrics', 'text_metrics_shortcode');
 
 function text_metrics_shortcode() {
     wp_enqueue_style('text-metrics-styles', plugin_dir_url(__FILE__) . 'assets/styles.css', array(), '1.0');
     wp_enqueue_script('text-metrics-script', plugin_dir_url(__FILE__) . 'assets/script.js', array('jquery'), '1.0', true);
     wp_localize_script('text-metrics-script', 'textMetricsAjax', array('ajax_url' => admin_url('admin-ajax.php')));
 
     $output = '<div class="text-metrics-wrap"> 
     <form id="text-metrics-form" action="" method="post"> 
     <textarea name="text" id="text-metrics-text" rows="10" cols="50" style="width: 100%;"></textarea><br>
     <input id="btncountwords" type="submit" name="submit" value="Examine Text">
     </form>
     </div>';
     
     $output .= '<div class="text-metrics-result">
     <p id="word-count">Word Count: 0</p>
     <p id="char-count">Character Count: 0</p>
     <p id="sentence-count">Sentence Count: 0</p> </div>';
  
 
     return $output;
 }
 
 add_action('wp_ajax_text_metrics_action', 'text_metrics_ajax_handler');
 add_action('wp_ajax_nopriv_text_metrics_action', 'text_metrics_ajax_handler');
 
 function text_metrics_ajax_handler() {
     $text = sanitize_textarea_field($_POST['text']);
     $word_count = str_word_count($text);
     $char_count = strlen($text);
     $sentence_count = preg_match_all('/[.!?]/', $text);
 
     $response = array(
         'word_count' => $word_count,
         'char_count' => $char_count,
         'sentence_count' => $sentence_count
     );
 
     echo json_encode($response);
     wp_die();
 }
